import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import net.proteanit.sql.DbUtils;

public class Compta extends JFrame {
	
	

	private JPanel contentPane;
	private JTextField clubF;
	private JTextField debitF;
	private JTextField creditF;
	private JTable table;
	Connection cnx = null;
	PreparedStatement prepared = null;
	ResultSet resultat = null;
	
	void fermer()
	{
		dispose();
	}

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Compta frame = new Compta();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Compta() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 692, 336);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		cnx = ConnexionMysql.ConnexionDb();
		
		clubF = new JTextField();
		clubF.setBounds(142, 55, 96, 20);
		contentPane.add(clubF);
		clubF.setColumns(10);
		
		debitF = new JTextField();
		debitF.setColumns(10);
		debitF.setBounds(142, 86, 96, 20);
		contentPane.add(debitF);
		
		creditF = new JTextField();
		creditF.setColumns(10);
		creditF.setBounds(142, 117, 96, 20);
		contentPane.add(creditF);
		
		JLabel lblNewLabel = new JLabel("Club :");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel.setBounds(102, 57, 36, 14);
		contentPane.add(lblNewLabel);
		
		JLabel lblLastName = new JLabel("D\u00E9bit :");
		lblLastName.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblLastName.setBounds(98, 89, 52, 14);
		contentPane.add(lblLastName);
		
		JLabel lblAdresse = new JLabel("Cr\u00E9dit :");
		lblAdresse.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblAdresse.setBounds(94, 119, 45, 14);
		contentPane.add(lblAdresse);
		
		JButton btnNewButton_4 = new JButton("");
		btnNewButton_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				MenuAdmin obj = new MenuAdmin();
				obj.setVisible(true);
				fermer();
				
			}
		});
		btnNewButton_4.setIcon(new ImageIcon("C:\\Users\\hp\\Downloads\\retour1.png"));
		btnNewButton_4.setBounds(0, 3, 30, 27);
		contentPane.add(btnNewButton_4);
		
				
		JButton btnNewButton_2 = new JButton("Delete ");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				int ligne = table.getSelectedRow();
				if(ligne == -1) 
				{
					JOptionPane.showMessageDialog(null, "Select a line !");
				}else
				{
					String id = table.getModel().getValueAt(ligne, 0).toString();
					
					String sql = " delete from compta where id = '"+id+"'";
					try {
						prepared = cnx.prepareStatement(sql);
						prepared.execute();
						JOptionPane.showMessageDialog(null, "Line deleted !");
						clubF.setText("");
		                debitF.setText("");
		                creditF.setText("");
					} catch (SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				}
					
				
						
						}
					}
				);
				btnNewButton_2.setBounds(10, 201, 128, 23);
				contentPane.add(btnNewButton_2);
				
				JButton btnNewButton_3 = new JButton("Refresh");
				btnNewButton_3.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						UpdateTable();
					}
				});
				btnNewButton_3.setBounds(300, 3, 87, 23);
				contentPane.add(btnNewButton_3);
		
		JButton btnNewButton = new JButton("Add ");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String club = clubF.getText().toString();
				String debit = debitF.getText().toString();
				String credit = creditF.getText().toString();
				
				String sql = "insert into compta ( club , debit , credit )  values ( ? , ? , ?  )";
				try {
					if(!club.equals("") && !debit.equals("") && !credit.equals("") )
					{
						prepared = cnx.prepareStatement(sql);
						prepared.setString(1, club);
						prepared.setString(2, debit);
						prepared.setString(3, credit);
						prepared.execute();
						
						clubF.setText("");
						debitF.setText("");
						creditF.setText("");
						JOptionPane.showMessageDialog(null, "Event added successfully !");
					}else {
						JOptionPane.showMessageDialog(null, "Fill all the blanks and try again !");
					}
					
					
					
					
					
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
				
				
				
			}
		});
		btnNewButton.setBounds(152, 201, 128, 23);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Update/Modify");
		btnNewButton_1.addActionListener(new ActionListener() {
        public void actionPerformed(ActionEvent e) {
        	int ligne = table.getSelectedRow();     
        	if(ligne == -1) 
			{
				JOptionPane.showMessageDialog(null, "Select a line !");
			}else {
				String id = table.getModel().getValueAt(ligne , 0). toString();
				
				String sql = " update compta set club = ? , credit = ? , debit = ? where id = '"+id+"'" ;
				
				try {
					
					prepared = cnx.prepareStatement(sql);
					prepared.setString(1, clubF.getText().toString());
					prepared.setString(2, debitF.getText().toString());
					prepared.setString(3, creditF.getText().toString());
					prepared.execute();
					JOptionPane.showMessageDialog(null, "User Updated !");
					UpdateTable();
					clubF.setText("");
	                debitF.setText("");
	                creditF.setText("");
	                
					
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
			}	
				
			}
			

		});
		btnNewButton_1.setBounds(74, 235, 128, 23);
		contentPane.add(btnNewButton_1);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(300, 22, 366, 265);
		contentPane.add(scrollPane);
		
		table = new JTable();
		table.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				int ligne = table.getSelectedRow();
				String id = table.getModel().getValueAt(ligne, 0).toString();
				String sql = " Select * from compta where id = '"+id+"'";
				
				try {
					prepared = cnx.prepareStatement(sql);
					resultat = prepared.executeQuery();
					
					if(resultat.next())
					{
						clubF.setText(resultat.getString("club"));
						debitF.setText(resultat.getString("debit"));
						creditF.setText(resultat.getString("credit"));
						
						
		
					}
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
				
			}
		});
		scrollPane.setViewportView(table);
		
		JLabel lblNewLabel1 = new JLabel("");
		lblNewLabel1.setForeground(Color.RED);
		lblNewLabel1.setIcon(new ImageIcon("C:\\Users\\hp\\Downloads\\background1.png"));
		lblNewLabel1.setBounds(0, 0, 683, 298);
		contentPane.add(lblNewLabel1);
		
		
	}
	public void UpdateTable() 
	{
		String sql = " select * from compta ";
		
		try {
			prepared = cnx.prepareStatement(sql);
			resultat = prepared.executeQuery();
			table.setModel(DbUtils.resultSetToTableModel(resultat));
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	
}
