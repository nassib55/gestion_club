import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.border.EmptyBorder;

import net.proteanit.sql.DbUtils;

import javax.swing.JTextField;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JComboBox;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.DefaultComboBoxModel;


public class GestionEven extends JFrame {

	private JPanel contentPane;
	private JTextField eventF;
	private JTextField clubF;
	private JTextField lieuxF;
	private JTextField dateF;
	private JTable table;
	Connection cnx = null;
	PreparedStatement prepared = null;
	ResultSet resultat = null;
	
	void fermer()
	{
		dispose();
	}

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					GestionEven frame = new GestionEven();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public GestionEven() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 692, 336);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		cnx = ConnexionMysql.ConnexionDb();
		
		eventF = new JTextField();
		eventF.setBounds(142, 55, 96, 20);
		contentPane.add(eventF);
		eventF.setColumns(10);
		
		clubF = new JTextField();
		clubF.setColumns(10);
		clubF.setBounds(142, 86, 96, 20);
		contentPane.add(clubF);
		
		lieuxF = new JTextField();
		lieuxF.setColumns(10);
		lieuxF.setBounds(142, 117, 96, 20);
		contentPane.add(lieuxF);
		
		dateF = new JTextField();
		dateF.setColumns(10);
		dateF.setBounds(142, 148, 96, 20);
		contentPane.add(dateF);
		
		JLabel lblNewLabel = new JLabel("Event :");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel.setBounds(95, 57, 52, 14);
		contentPane.add(lblNewLabel);
		
		JLabel lblLastName = new JLabel("Club :");
		lblLastName.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblLastName.setBounds(100, 89, 52, 14);
		contentPane.add(lblLastName);
		
		JLabel lblAdresse = new JLabel("Lieux  :");
		lblAdresse.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblAdresse.setBounds(91, 119, 45, 14);
		contentPane.add(lblAdresse);
		
		JLabel lblDateDeNaissance = new JLabel("Date :");
		lblDateDeNaissance.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblDateDeNaissance.setBounds(100, 150, 41, 14);
		contentPane.add(lblDateDeNaissance);
		
		JButton btnNewButton_4 = new JButton("");
		btnNewButton_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				MenuAdmin obj = new MenuAdmin();
				obj.setVisible(true);
				fermer();
				
			}
		});
		btnNewButton_4.setIcon(new ImageIcon("C:\\Users\\hp\\Downloads\\retour1.png"));
		btnNewButton_4.setBounds(0, 3, 30, 27);
		contentPane.add(btnNewButton_4);
		
				
		JButton btnNewButton_2 = new JButton("Delete Event");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				int ligne = table.getSelectedRow();
				if(ligne == -1) 
				{
					JOptionPane.showMessageDialog(null, "Select a student !");
				}else
				{
					String id = table.getModel().getValueAt(ligne, 0).toString();
					
					String sql = " delete from evenements where id_event = '"+id+"'";
					try {
						prepared = cnx.prepareStatement(sql);
						prepared.execute();
						JOptionPane.showMessageDialog(null, "User deleted !");
						eventF.setText("");
		                clubF.setText("");
		                lieuxF.setText("");
		                dateF.setText("");
					} catch (SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				}
					
				
						
						}
					}
				);
				btnNewButton_2.setBounds(10, 201, 128, 23);
				contentPane.add(btnNewButton_2);
				
				JButton btnNewButton_3 = new JButton("Refresh");
				btnNewButton_3.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						UpdateTable();
					}
				});
				btnNewButton_3.setBounds(300, 3, 87, 23);
				contentPane.add(btnNewButton_3);
		
		JButton btnNewButton = new JButton("Add Event");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String event = eventF.getText().toString();
				String club = clubF.getText().toString();
				String lieux = lieuxF.getText().toString();
				String date = dateF.getText().toString();
				
				String sql = "insert into evenements ( event , club , lieux , date )  values ( ? , ? , ? , ? )";
				try {
					if(!event.equals("") && !club.equals("") && !lieux.equals("") && !date.equals("") )
					{
						prepared = cnx.prepareStatement(sql);
						prepared.setString(1, event);
						prepared.setString(2, club);
						prepared.setString(3, lieux);
						prepared.setString(4, date);
						prepared.execute();
						
						eventF.setText("");
						clubF.setText("");
						lieuxF.setText("");
						dateF.setText("");
						JOptionPane.showMessageDialog(null, "Event added successfully !");
					}else {
						JOptionPane.showMessageDialog(null, "Fill all the blanks and try again !");
					}
					
					
					
					
					
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
				
				
				
			}
		});
		btnNewButton.setBounds(152, 201, 128, 23);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Update/Modify");
		btnNewButton_1.addActionListener(new ActionListener() {
        public void actionPerformed(ActionEvent e) {
        	int ligne = table.getSelectedRow();     
        	if(ligne == -1) 
			{
				JOptionPane.showMessageDialog(null, "Select a student !");
			}else {
				String id = table.getModel().getValueAt(ligne , 0). toString();
				
				String sql = " update evenements set event = ? , club = ? , lieux = ? , date = ? where id_event = '"+id+"'" ;
				
				try {
					
					prepared = cnx.prepareStatement(sql);
					prepared.setString(1, eventF.getText().toString());
					prepared.setString(2, clubF.getText().toString());
					prepared.setString(3, lieuxF.getText().toString());
					prepared.setString(4, dateF.getText().toString());
					prepared.execute();
					JOptionPane.showMessageDialog(null, "User Updated !");
					UpdateTable();
					eventF.setText("");
	                clubF.setText("");
	                lieuxF.setText("");
	                dateF.setText("");
					
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
			}	
				
			}
			

		});
		btnNewButton_1.setBounds(74, 235, 128, 23);
		contentPane.add(btnNewButton_1);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(300, 22, 366, 265);
		contentPane.add(scrollPane);
		
		table = new JTable();
		table.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				int ligne = table.getSelectedRow();
				String id = table.getModel().getValueAt(ligne, 0).toString();
				String sql = " Select * from evenements where id_event = '"+id+"'";
				
				try {
					prepared = cnx.prepareStatement(sql);
					resultat = prepared.executeQuery();
					
					if(resultat.next())
					{
						eventF.setText(resultat.getString("event"));
						clubF.setText(resultat.getString("club"));
						lieuxF.setText(resultat.getString("lieux"));
						dateF.setText(resultat.getString("Date"));
						
		
					}
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
				
			}
		});
		scrollPane.setViewportView(table);
		
		JLabel lblNewLabel1 = new JLabel("");
		lblNewLabel1.setForeground(Color.RED);
		lblNewLabel1.setIcon(new ImageIcon("C:\\Users\\hp\\Downloads\\background1.png"));
		lblNewLabel1.setBounds(0, 0, 683, 298);
		contentPane.add(lblNewLabel1);
		
		
	}
	public void UpdateTable() 
	{
		String sql = " select * from evenements ";
		
		try {
			prepared = cnx.prepareStatement(sql);
			resultat = prepared.executeQuery();
			table.setModel(DbUtils.resultSetToTableModel(resultat));
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
}
