import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.border.EmptyBorder;

import net.proteanit.sql.DbUtils;

import javax.swing.JTextField;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JComboBox;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.DefaultComboBoxModel;


public class GestionEtud extends JFrame {

	private JPanel contentPane;
	private JTextField prenomF;
	private JTextField nomF;
	private JTextField cinF;
	private JTextField adresseF;
	private JTextField telF;
	private JTextField datenaissanceF;
	private JTable table;
	Connection cnx = null;
	PreparedStatement prepared = null;
	ResultSet resultat = null;
	
	void fermer()
	{
		dispose();
	}

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					GestionEtud frame = new GestionEtud();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public GestionEtud() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 692, 336);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		cnx = ConnexionMysql.ConnexionDb();
		
		prenomF = new JTextField();
		prenomF.setBounds(142, 33, 96, 20);
		contentPane.add(prenomF);
		prenomF.setColumns(10);
		
		nomF = new JTextField();
		nomF.setColumns(10);
		nomF.setBounds(142, 56, 96, 20);
		contentPane.add(nomF);
		
		cinF = new JTextField();
		cinF.setColumns(10);
		cinF.setBounds(142, 79, 96, 20);
		contentPane.add(cinF);
		
		adresseF = new JTextField();
		adresseF.setColumns(10);
		adresseF.setBounds(142, 125, 96, 20);
		contentPane.add(adresseF);
		
		telF = new JTextField();
		telF.setColumns(10);
		telF.setBounds(142, 102, 96, 20);
		contentPane.add(telF);
		
		datenaissanceF = new JTextField();
		datenaissanceF.setColumns(10);
		datenaissanceF.setBounds(142, 148, 96, 20);
		contentPane.add(datenaissanceF);
		
		JLabel lblNewLabel = new JLabel("First Name :");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblNewLabel.setBounds(74, 36, 67, 14);
		contentPane.add(lblNewLabel);
		
		JLabel lblLastName = new JLabel("Last Name :");
		lblLastName.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblLastName.setBounds(74, 59, 67, 14);
		contentPane.add(lblLastName);
		
		JLabel lblCin = new JLabel("CIN :");
		lblCin.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblCin.setBounds(114, 82, 27, 14);
		contentPane.add(lblCin);
		
		JLabel lblNumTl = new JLabel("Num t\u00E9l :");
		lblNumTl.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblNumTl.setBounds(91, 105, 50, 14);
		contentPane.add(lblNumTl);
		
		JLabel lblAdresse = new JLabel("Adresse :");
		lblAdresse.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblAdresse.setBounds(88, 128, 53, 14);
		contentPane.add(lblAdresse);
		
		JLabel lblDateDeNaissance = new JLabel("Date de naissance :");
		lblDateDeNaissance.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblDateDeNaissance.setBounds(31, 151, 110, 14);
		contentPane.add(lblDateDeNaissance);
		
		JButton btnNewButton_4 = new JButton("");
		btnNewButton_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				MenuAdmin obj = new MenuAdmin();
				obj.setVisible(true);
				fermer();
				
			}
		});
		btnNewButton_4.setIcon(new ImageIcon("C:\\Users\\hp\\Downloads\\retour1.png"));
		btnNewButton_4.setBounds(0, 3, 30, 27);
		contentPane.add(btnNewButton_4);
		
				
		JButton btnNewButton_2 = new JButton("Delete User");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				int ligne = table.getSelectedRow();
				if(ligne == -1) 
				{
					JOptionPane.showMessageDialog(null, "Select a student !");
				}else
				{
					String id = table.getModel().getValueAt(ligne, 0).toString();
					
					String sql = " delete from etudiants where id_etudiant = '"+id+"'";
					try {
						prepared = cnx.prepareStatement(sql);
						prepared.execute();
						JOptionPane.showMessageDialog(null, "User deleted !");
					} catch (SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				}
					
				
						
						}
					}
				);
				btnNewButton_2.setBounds(10, 201, 128, 23);
				contentPane.add(btnNewButton_2);
				
				JButton btnNewButton_3 = new JButton("Refresh");
				btnNewButton_3.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						UpdateTable();
					}
				});
				btnNewButton_3.setBounds(331, 3, 96, 23);
				contentPane.add(btnNewButton_3);
		
		JButton btnNewButton = new JButton("Add new user");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String prenom = prenomF.getText().toString();
				String nom = nomF.getText().toString();
				String cin = cinF.getText().toString();
				String tel = telF.getText().toString();
				String adresse = adresseF.getText().toString();
				String datenaissance = datenaissanceF.getText().toString();
				 
				
				String sql = "insert into etudiants ( prenom , nom , cin , tel , DatedeNaissance , adresse )  values ( ? , ? , ? , ? , ? , ? )";
				try {
					if(!prenom.equals("") && !nom.equals("") && !cin.equals("") && !tel.equals("") &&!adresse.equals("") && !datenaissance.equals("")  )
					{
						prepared = cnx.prepareStatement(sql);
						prepared.setString(1, prenom);
						prepared.setString(2, nom);
						prepared.setString(3, cin);
						prepared.setString(4, tel);
						prepared.setString(5, datenaissance);
						prepared.setString(6, adresse);
						prepared.execute();
						
						prenomF.setText("");
						nomF.setText("");
						cinF.setText("");
						telF.setText("");
						adresseF.setText("");
						datenaissanceF.setText("");
						JOptionPane.showMessageDialog(null, "REGISTRATION SUCCESSFUL !");
					}else {
						JOptionPane.showMessageDialog(null, "Fill all the blanks and try again !");
					}
					
					
					
					
					
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
				
				
				
			}
		});
		btnNewButton.setBounds(152, 201, 128, 23);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Update/Modify");
		btnNewButton_1.addActionListener(new ActionListener() {
        public void actionPerformed(ActionEvent e) {
        	int ligne = table.getSelectedRow();     
        	if(ligne == -1) 
			{
				JOptionPane.showMessageDialog(null, "Select a student !");
			}else {
				String id = table.getModel().getValueAt(ligne , 0). toString();
				
				String sql = " update etudiants set prenom = ? , nom = ? , cin = ? , tel = ? , adresse = ? , DatedeNaissance = ?  where id_etudiant = '"+id+"'" ;
				
				try {
					
					prepared = cnx.prepareStatement(sql);
					prepared.setString(1, prenomF.getText().toString());
					prepared.setString(2, nomF.getText().toString());
					prepared.setString(3, cinF.getText().toString());
					prepared.setString(4, telF.getText().toString());
					prepared.setString(5, adresseF.getText().toString());
					prepared.setString(6, datenaissanceF.getText().toString());
					
					
					prepared.execute();
					JOptionPane.showMessageDialog(null, "User Updated !");
					UpdateTable();
					
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
			}	
				
			}
			

		});
		btnNewButton_1.setBounds(74, 235, 128, 23);
		contentPane.add(btnNewButton_1);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(331, 22, 335, 265);
		contentPane.add(scrollPane);
		
		table = new JTable();
		table.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				int ligne = table.getSelectedRow();
				String id = table.getModel().getValueAt(ligne, 0).toString();
				String sql = " Select * from etudiants where id_etudiant = '"+id+"'";
				
				try {
					prepared = cnx.prepareStatement(sql);
					resultat = prepared.executeQuery();
					
					if(resultat.next())
					{
						prenomF.setText(resultat.getString("prenom"));
						nomF.setText(resultat.getString("nom"));
						cinF.setText(resultat.getString("cin"));
						telF.setText(resultat.getString("tel"));
						adresseF.setText(resultat.getString("adresse"));
						datenaissanceF.setText(resultat.getString("DatedeNaissance"));
						
					}
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
				
			}
		});
		scrollPane.setViewportView(table);
		
		JLabel lblNewLabel1 = new JLabel("");
		lblNewLabel1.setForeground(Color.RED);
		lblNewLabel1.setIcon(new ImageIcon("C:\\Users\\hp\\Downloads\\background1.png"));
		lblNewLabel1.setBounds(0, 0, 683, 298);
		contentPane.add(lblNewLabel1);
		
		
	}
	public void UpdateTable() 
	{
		String sql = " select * from etudiants ";
		
		try {
			prepared = cnx.prepareStatement(sql);
			resultat = prepared.executeQuery();
			table.setModel(DbUtils.resultSetToTableModel(resultat));
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
}
