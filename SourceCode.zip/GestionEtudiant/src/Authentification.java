import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.ImageIcon;
import javax.swing.JTextField;
import java.awt.Color;
import javax.swing.JButton;
import javax.swing.JPasswordField;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
/**
 * java doc 
 * @author hp
 *
 */

public class Authentification extends JFrame {

	private JFrame frame;
	private JTextField usernamefield;
	private JPasswordField passwordfield;
	void fermer()
	{
		frame.dispose();
	}

	
	Connection cnx = null;
	PreparedStatement prepared = null;
	ResultSet resultat = null;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Authentification window = new Authentification();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Authentification() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setResizable(false);
		frame.setBounds(100, 100, 692, 336);
		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		cnx = ConnexionMysql.ConnexionDb();
		
		usernamefield = new JTextField();
		usernamefield.setFont(new Font("Times New Roman", Font.BOLD, 12));
		usernamefield.setBounds(274, 87, 144, 25);
		frame.getContentPane().add(usernamefield);
		usernamefield.setColumns(10);
		
		passwordfield = new JPasswordField();
		passwordfield.setFont(new Font("Times New Roman", Font.PLAIN, 12));
		passwordfield.setBounds(274, 131, 144, 25);
		frame.getContentPane().add(passwordfield);
		
		JLabel lblUsername = new JLabel("Username :");
		lblUsername.setFont(new Font("Times New Roman", Font.BOLD, 12));
		lblUsername.setForeground(Color.BLACK);
		lblUsername.setBounds(200, 84, 74, 30);
		frame.getContentPane().add(lblUsername);
		
		JLabel lblPassword = new JLabel("Password :");
		lblPassword.setFont(new Font("Times New Roman", Font.BOLD, 12));
		lblPassword.setForeground(Color.BLACK);
		lblPassword.setBounds(200, 128, 74, 30);
		frame.getContentPane().add(lblPassword);
		
		JButton btnNewButton = new JButton("Login");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String username = usernamefield.getText().toString();
				String password = passwordfield.getText().toString();
				int i = 0;
				if (username.equals("") || password.equals("")) {
			    	JOptionPane.showMessageDialog(null, "Fill all the blank fields !!");
				}		
               String sql1 = "select nom, passwd from admin";
				
				try {
					prepared = cnx.prepareStatement(sql1);
					resultat = prepared.executeQuery()	;
					
				    	while(resultat.next())
						{
							String username1 = resultat.getString("nom");
							String password1 = resultat.getString("passwd");
							
							if(username1.equals(username) && password1.equals(password) ) 
							{
								JOptionPane.showMessageDialog(null, "Successful Connection !");
								i=1 ;
								MenuAdmin obj = new MenuAdmin();
								obj.setVisible(true);
								fermer();
							}						
						}				    	
				    }	
				catch (SQLException e1) {
					e1.printStackTrace();
				}	
                String sql = "select username, password from utilisateur";		
				try {
					prepared = cnx.prepareStatement(sql);
					resultat = prepared.executeQuery()	;
					
				    	while(resultat.next())
						{
							String username1 = resultat.getString("username");
							String password1 = resultat.getString("password");
							
							if(username1.equals(username) && password1.equals(password) ) 
							{
								JOptionPane.showMessageDialog(null, "Successful Connection !");
								i=1 ;
								InterfaceUser obj = new InterfaceUser();
								obj.setVisible(true);
								fermer();
							}					
						}    	
				    }			
				 catch (SQLException e1) {
					e1.printStackTrace();
				}
				if ( i == 0)
					JOptionPane.showMessageDialog(null,"Connection Failed ! Incorrect informations");
								
			}						
			}
			);
		
		
		btnNewButton.setBounds(303, 193, 89, 23);
		frame.getContentPane().add(btnNewButton);
		
		JLabel lblNewLabel_1 = new JLabel("Incorrect password ?");
		lblNewLabel_1.setFont(new Font("Times New Roman", Font.BOLD, 12));
		lblNewLabel_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				IndicationMdp obj = new IndicationMdp();
				obj.setVisible(true);
				obj.setLocationRelativeTo(null);
				
			}
		});
		lblNewLabel_1.setForeground(Color.BLACK);
		lblNewLabel_1.setBounds(306, 157, 112, 25);
		frame.getContentPane().add(lblNewLabel_1);
		
		JLabel lblGestionDesEtudiants = new JLabel("Ecole National des Sciences Appliqu\u00E9es d' El Jadida");
		lblGestionDesEtudiants.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblGestionDesEtudiants.setForeground(Color.BLACK);
		lblGestionDesEtudiants.setBounds(118, 14, 457, 43);
		frame.getContentPane().add(lblGestionDesEtudiants);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setForeground(Color.RED);
		lblNewLabel.setIcon(new ImageIcon("C:\\Users\\hp\\Downloads\\background1.png"));
		lblNewLabel.setBounds(0, 0, 683, 310);
		frame.getContentPane().add(lblNewLabel);
	}
}
