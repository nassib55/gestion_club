import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

public class InterfaceUser extends JFrame {

	private JPanel contentPane;
	void fermer()
	{
		dispose();
	}


	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					InterfaceUser frame = new InterfaceUser();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public InterfaceUser() {
		setResizable(false);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 692, 336);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel_1 = new JLabel("Gestion des membres");
		lblNewLabel_1.setForeground(Color.BLACK);
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_1.setBounds(87, 130, 149, 14);
		contentPane.add(lblNewLabel_1);
		
		JButton btnNewButton_1 = new JButton("");
		btnNewButton_1.setEnabled(false);
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				GestionUsers obj = new GestionUsers();
				obj.setVisible(true);
				fermer();
			}
		});
		btnNewButton_1.setIcon(new ImageIcon("C:\\Users\\hp\\Downloads\\membres1.png"));
		btnNewButton_1.setBounds(99, 11, 125, 111);
		contentPane.add(btnNewButton_1);
		
		JLabel lblNewLabel = new JLabel("Plannification des\r\n \u00E9v\u00E9nements");
		lblNewLabel.setForeground(Color.BLACK);
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel.setBounds(365, 271, 218, 14);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_2 = new JLabel("Comptabilit\u00E9 G\u00E9n\u00E9rale");
		lblNewLabel_2.setForeground(Color.BLACK);
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_2.setBounds(387, 130, 157, 14);
		contentPane.add(lblNewLabel_2);
		
		JButton btnNewButton_3 = new JButton("");
		btnNewButton_3.setEnabled(false);
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				GestionEtud obj = new GestionEtud();
				obj.setVisible(true);
				setLocationRelativeTo(null);
				fermer ();
			}
		});
		btnNewButton_3.setIcon(new ImageIcon("C:\\Users\\hp\\Downloads\\etud12.png"));
		btnNewButton_3.setBounds(97, 155, 129, 111);
		contentPane.add(btnNewButton_3);
		
		JLabel lblGestionDestudiants = new JLabel("Gestion des \u00E9tudiants");
		lblGestionDestudiants.setForeground(Color.BLACK);
		lblGestionDestudiants.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblGestionDestudiants.setBounds(87, 271, 157, 14);
		contentPane.add(lblGestionDestudiants);
		
		JButton btnNewButton_2 = new JButton("");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				GestionEvenUser obj = new GestionEvenUser();
				obj.setVisible(true);
				setLocationRelativeTo(null);
				fermer();
			}
		});
		btnNewButton_2.setIcon(new ImageIcon("C:\\Users\\hp\\Downloads\\plannification11.jpg"));
		btnNewButton_2.setBounds(401, 155, 125, 105);
		contentPane.add(btnNewButton_2);
		
		JButton btnNewButton = new JButton("");
		btnNewButton.setEnabled(false);
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Compta obj = new Compta();
				obj.setVisible(true);
				setLocationRelativeTo(null);
				fermer();
			}
		});
		btnNewButton.setIcon(new ImageIcon("C:\\Users\\hp\\Downloads\\compta3.png"));
		btnNewButton.setBounds(401, 11, 125, 111);
		contentPane.add(btnNewButton);
		
		JLabel lblNewLabel1 = new JLabel("");
		lblNewLabel1.setForeground(Color.RED);
		lblNewLabel1.setIcon(new ImageIcon("C:\\Users\\hp\\Downloads\\background1.png"));
		lblNewLabel1.setBounds(0, 0, 683, 308);
		contentPane.add(lblNewLabel1);
	}

}